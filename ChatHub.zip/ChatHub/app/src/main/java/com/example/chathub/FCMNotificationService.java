package com.example.chathub;

import com.google.firebase.messaging.FirebaseMessagingService;

public class FCMNotificationService extends FirebaseMessagingService {
}
